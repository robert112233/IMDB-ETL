def extract(event, context):
    return "hello"